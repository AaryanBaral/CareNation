import React from "react";

const treeData = {
  id: "A",
  name: "User A",
  children: [
    {
      id: "B",
      name: "User B",
      children: [
        { id: "D", name: "User D", children: [] },
        { id: "E", name: "User E", children: [] }
      ]
    },
    {
      id: "C",
      name: "User C",
      children: [
        { id: "F", name: "User F", children: [] }
      ]
    }
  ]
};

function TreeNode({ node, level = 0 }) {
  return (
    <div style={{ paddingLeft: `${level * 20}px`, marginBottom: "6px" }}>
      <strong>{node.name}</strong>
      {node.children && node.children.length > 0 && (
        <div style={{ marginTop: "5px" }}>
          {node.children.map(child => (
            <TreeNode key={child.id} node={child} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

function TreeView() {
  return (
    <div className="card">
      <h3>Referral Tree View</h3>
      <TreeNode node={treeData} />
    </div>
  );
}

export default TreeView;
