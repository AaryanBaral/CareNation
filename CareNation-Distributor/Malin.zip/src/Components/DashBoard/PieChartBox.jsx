import React, { useEffect, useState } from "react";
import { PieChart, Pie, Cell, Legend, ResponsiveContainer } from "recharts";
import axios from "axios";
import baseApi from "../Constants/baseApi";

const COLORS = ["#ef4444", "#10b981", "#6366f1", "#f59e42", "#3b82f6"];

function PieChartBox() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let mounted = true;
    baseApi.get("reports/sales-by-category")
      .then(res => {
        const arr = Array.isArray(res.data) ? res.data : [];
        if (mounted) {
          setData(arr.map(cat => ({
            name: cat.categoryName,
            value: cat.totalSales || 0
          })));
          setLoading(false);
        }
      })
      .catch(() => {
        if (mounted) {
          setData([]);
          setLoading(false);
        }
      });
    return () => { mounted = false; };
  }, []);

  if (loading) return <div>Loading pie chart...</div>;
  if (!data || data.length === 0) return <div>No category sales data.</div>;

  return (
    <div className="card">
      <h3>Revenue Breakdown</h3>
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={100}
            dataKey="value"
            label
          >
            {data.map((entry, index) => (
              <Cell key={index} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

export default PieChartBox;
