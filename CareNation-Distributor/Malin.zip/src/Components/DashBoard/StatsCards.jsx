import React, { useEffect, useState } from "react";
import { FaChartLine, FaUserCheck, FaUsers, FaWallet } from "react-icons/fa";
import baseApi from "../Constants/baseApi";

export default function StatsCards() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function fetchStats() {
      try {
        const [individualRes, salesRes, referralRes, downlineRes] = await Promise.all([
          baseApi.get("/distributor/individual"),
          baseApi.get("/reports/total-sales"),
          baseApi.get("/distributor/total-referrals"),
          baseApi.get("/distributor/total-downlines")
        ]);
        const individual = individualRes.data;
        const sales = salesRes.data;
        const totalReferrals = referralRes.data;
        console.log(totalReferrals)
        const totalDownlines = downlineRes.data;

        if (mounted) {
          setStats({
            totalCommissions: individual.totalcomission || 0,
            totalWallet: individual.totalWallet || 0,
            totalReferrals: totalReferrals.totalReferrals || 0,
            totalDownlines: totalDownlines.totalDownlines || 0,
            totalSales :sales.teamSales + sales.personalSales
          });
          setLoading(false);
        }
      } catch (err) {
        console.log("Failed to load stats:", err);
        setStats(null);
        setLoading(false);
      }
    }

    fetchStats();
    return () => { mounted = false; };
  }, []);

  if (loading) return <div>Loading...</div>;
  if (!stats) return <div>No data available.</div>;

  return (
    <div style={{ display: "flex", gap: "20px", flexWrap: "wrap" }}>
      <div className="card" style={{ flex: 1, minWidth: "200px" }}>
        <FaUsers /> <strong>Total Referrals</strong>
        <h2>{stats.totalReferrals}</h2>
      </div>
      <div className="card" style={{ flex: 1, minWidth: "200px" }}>
        <FaUserCheck /> <strong>Total Downline</strong>
        <h2>{stats.totalDownlines}</h2>
      </div>
      <div className="card" style={{ flex: 1, minWidth: "200px" }}>
        <FaChartLine /> <strong>Total Sales</strong>
        <h2>Rs. {stats.totalSales.toLocaleString()}</h2>
      </div>
      <div className="card" style={{ flex: 1, minWidth: "200px" }}>
        <FaWallet /> <strong>Total Wallet</strong>
        <h2>Rs. {stats.totalWallet.toLocaleString()}</h2>
      </div>
      <div className="card" style={{ flex: 1, minWidth: "200px" }}>
        💰 <strong>Total Commission</strong>
        <h2>Rs. {stats.totalCommissions.toLocaleString()}</h2>
      </div>
    </div>
  );
}
