import React from 'react';
import { FaUserCircle } from 'react-icons/fa';

const TreeNode = ({ node, level, position = 'root', onClick }) => {
  const getNodeColor = (level) => {
    switch (level) {
      case 1:
        return 'tree-node-level-1';
      case 2:
        return 'tree-node-level-2';
      case 3:
        return 'tree-node-level-3';
      default:
        return 'tree-node-level-3';
    }
  };

  const getPositionStyles = () => {
    return 'transition-all duration-300';
  };

  return (
    <div className={`flex flex-col items-center animate-fade-in ${getPositionStyles()}`}>
      <div
        onClick={() => onClick(node)}
        className={`
          ${getNodeColor(level)} 
          rounded-full w-14 h-14 md:w-18 md:h-18 
          flex items-center justify-center 
          cursor-pointer transition-all duration-300 
          hover:scale-110 hover:shadow-lg hover:shadow-primary/30
          border-3 border-white shadow-md
          group relative
        `}
      >
        <FaUserCircle className="text-2xl md:text-3xl text-white" />

        {/* Hover tooltip */}
        <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-card px-3 py-1 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
          <p className="text-sm font-medium text-card-foreground">{node.name}</p>
          <p className="text-xs text-muted-foreground">{node.position}</p>
        </div>
      </div>

      <div className="mt-2 text-center max-w-20">
        <p className="text-xs md:text-sm font-semibold text-foreground truncate">{node.name}</p>
        <p className="text-xs text-muted-foreground truncate">{node.position}</p>
      </div>
    </div>
  );
};

export default TreeNode;
