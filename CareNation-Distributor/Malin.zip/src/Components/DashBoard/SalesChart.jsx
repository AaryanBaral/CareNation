import React, { useEffect, useState, useContext } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import DarkModeContext from "../Context/DarkModeContext";
import baseApi from "../Constants/baseApi";

const SalesChart = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { darkMode } = useContext(DarkModeContext);

  useEffect(() => {
    let mounted = true;

    baseApi.get("/my-reports/team-sales-by-time?period=month")
      .then(res => {
        console.log(res);
        const arr = Array.isArray(res.data) ? res.data : [];
        if (mounted) {
          setData(arr.map(item => ({
            name: item.date
              ? new Date(item.date).toLocaleString('default', { month: 'short', year: 'numeric' })
              : "Unknown",
            sales: item.totalSales || 0,
          })));
          setLoading(false);
        }
      })
      .catch(err => {
        console.error("Failed to fetch sales chart:", err);
        if (mounted) {
          setData([]);
          setLoading(false);
        }
      });

    return () => { mounted = false; };
  }, []);

  if (loading) return <div>Loading sales chart...</div>;
  if (!data || data.length === 0) return <div>No sales data.</div>;

  return (
    <div style={{
      background: darkMode ? "#1f2937" : "#f9fafb",
      padding: "20px",
      borderRadius: "12px",
      boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
      marginBottom: "20px"
    }}>
      <h3 style={{ color: darkMode ? "#fff" : "#111827", marginBottom: "10px" }}>📊 Team Sales Overview</h3>
      <ResponsiveContainer width="100%" height={250}>
        <BarChart data={data}>
          <XAxis dataKey="name" stroke={darkMode ? "#fff" : "#000"} />
          <YAxis stroke={darkMode ? "#fff" : "#000"} />
          <Tooltip />
          <Bar dataKey="sales" fill={darkMode ? "#38bdf8" : "#2563eb"} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default SalesChart;
