import React from "react";
import "../../styles/App.css";

function ExportButtons() {
  const handleExport = (type) => {
    alert(`Exporting data as ${type} (mock action)`);
  };

  return (
    <div className="card" style={{ textAlign: "center" }}>
      <h3>📤 Export Reports</h3>
      <div style={{ marginTop: "10px" }}>
        <button
          onClick={() => handleExport("CSV")}
          style={{
            backgroundColor: "#2563eb",
            color: "#fff",
            padding: "10px 15px",
            marginRight: "10px",
            border: "none",
            borderRadius: "6px",
            cursor: "pointer",
          }}
        >
          📄 Export CSV
        </button>
        <button
          onClick={() => handleExport("PDF")}
          style={{
            backgroundColor: "#dc2626",
            color: "#fff",
            padding: "10px 15px",
            border: "none",
            borderRadius: "6px",
            cursor: "pointer",
          }}
        >
          📕 Export PDF
        </button>
      </div>
    </div>
  );
}

export default ExportButtons;
