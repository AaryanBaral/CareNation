// src/context/AuthContext.jsx
import React, { createContext, useContext, useEffect, useState } from "react";
import baseApi from "../Constants/baseApi";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem("token"));
  const [expiryTime, setExpiryTime] = useState(null);
  const [isDistributor, setIsDistributor] = useState(
    () => localStorage.getItem("isDistributor") === "true"
  );

  // NEW: track impersonation (for banner / exit)
  const [isImpersonating, setIsImpersonating] = useState(
    () => localStorage.getItem("isImpersonating") === "true"
  );

  // keep your existing helper
  const setExpiry = () => {
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 10 * 60 * 60 * 1000); // 10h
    localStorage.setItem("tokenExpiresAt", expiresAt.toISOString());
    setExpiryTime(expiresAt);
  };

  const login = (newToken) => {
    localStorage.setItem("token", newToken);   // single key for BOTH normal + impersonation
    setToken(newToken);
  };

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("tokenExpiresAt");
    localStorage.removeItem("isImpersonating");
    localStorage.removeItem("impersonationReturnUrl");
    setToken(null);
    setExpiryTime(null);
    setIsImpersonating(false);
  };

  function isTokenExpired() {
    const expiresAt = localStorage.getItem("tokenExpiresAt");
    if (!expiresAt) return true;
    return new Date() > new Date(expiresAt);
  }

  // persist existing flags
  useEffect(() => {
    localStorage.setItem("isDistributor", isDistributor);
    if (token) localStorage.setItem("token", token);
    else localStorage.removeItem("token");
  }, [isDistributor, token]);

  // keep axios header in sync immediately when token changes
  useEffect(() => {
    if (token) baseApi.defaults.headers.Authorization = `Bearer ${token}`;
    else delete baseApi.defaults.headers.Authorization;
  }, [token]);

  // ✅ Global bootstrap: redeem impersonation code on ANY page, no middle route
  useEffect(() => {
    (async () => {
      try {
        const url = new URL(window.location.href);
        const code = url.searchParams.get("code");
        const ret  = url.searchParams.get("returnUrl");
        if (!code) return;

        // redeem
        const { data } = await baseApi.post("/auth/impersonation/redeem", { code });
        const { accessToken, expiresAtUtc, returnUrl: serverReturn } = data;

        // store token (single key) — impersonation replaces normal token
        login(accessToken);

        // set expiry from server (impersonation is short-lived)
        if (expiresAtUtc) {
          localStorage.setItem("tokenExpiresAt", new Date(expiresAtUtc).toISOString());
          setExpiryTime(new Date(expiresAtUtc));
        } else {
          setExpiry(); // fallback to your 10h window if server didn't send
        }

        // remember where to send "Exit"
        if (ret || serverReturn) {
          localStorage.setItem("impersonationReturnUrl", ret || serverReturn);
        }

        // mark impersonation active & clean URL (remove ?code, keep the same page)
        setIsImpersonating(true);
        url.searchParams.delete("code");
        url.searchParams.delete("returnUrl");
        const clean = url.pathname + (url.search || "") + (url.hash || "");
        window.history.replaceState({}, "", clean);
      } catch (e) {
        console.error("Impersonation redeem failed:", e);
        // optional: toast or redirect to /login
      }
    })();
    // run once on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 🔚 exit back to admin
  const exitImpersonation = () => {
    const ret = localStorage.getItem("impersonationReturnUrl");
    logout(); // clears token + flags
    window.location.assign(ret || "http://localhost:5173/"); // fallback admin URL
  };

  return (
    <AuthContext.Provider
      value={{
        token,
        setToken,
        isDistributor,
        setIsDistributor,
        login,
        logout,
        setExpiry,
        isTokenExpired,
        // new
        isImpersonating,
        exitImpersonation,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
