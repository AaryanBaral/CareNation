import React, { useState, useCallback, useEffect } from 'react';
import baseApi from "../Components/Constants/baseApi"; // Adjust path as needed
import '../styles/TreeListing.css';
import Modal from './Modal';
import Tree from './Tree';

function App() {
  const [treeData, setTreeData] = useState(null);     // API-loaded tree data
  const [currentRoot, setCurrentRoot] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedNode, setSelectedNode] = useState(null);

  // Fetch binary tree data from API
  useEffect(() => {
    const getTreeData = async () => {
      try {
        const res = await baseApi.get("distributor/tree"); // Make sure endpoint is correct!
        setTreeData(res.data);
        setCurrentRoot(res.data); // Start at root
      } catch (err) {
        console.error("Error fetching tree:", err);
      }
    };
    getTreeData();
  }, []);

  // Recursive node finder (moves inside component for simplicity)
  const findNodeById = useCallback((node, id) => {
    if (!node) return null;
    if (node.id === id) return node;
    if (!node.children) return null;
    for (const child of node.children) {
      const found = findNodeById(child, id);
      if (found) return found;
    }
    return null;
  }, []);

  // Change root when a node is clicked
  const handleNodeClick = useCallback((node) => {
    const foundNode = findNodeById(treeData, node.id);
    if (foundNode) {
      setCurrentRoot(foundNode);
    }
  }, [treeData, findNodeById]);

  // Open update parent modal
  const handleUpdateParent = useCallback((node) => {
    setSelectedNode(node);
    setModalOpen(true);
  }, []);

  // Dummy parent update handler
  const handleParentUpdate = useCallback((nodeId, newParentId) => {
    alert(`Demo: Would move node ${nodeId} to parent ${newParentId}`);
    console.log('Update request:', { nodeId, newParentId });
  }, []);

  // Back to original root
  const handleResetToRoot = () => {
    setCurrentRoot(treeData);
  };

  const isAtOriginalRoot = currentRoot && treeData && currentRoot.id === treeData.id;

  if (!treeData || !currentRoot) return <p>Loading tree...</p>;

  return (
    <div className="tree">
      <header className="tree-header">
        <h1 className="tree-title">Binary Network Marketing Tree</h1>
        <p className="tree-subtitle">
          Interactive network visualization with 3-level view
        </p>
        {!isAtOriginalRoot && (
          <button 
            onClick={handleResetToRoot}
            className="btn btn-secondary"
            style={{ marginTop: '15px' }}
          >
            ← Back to Root
          </button>
        )}
      </header>

      <main className="tree-container">
        <Tree
          rootNode={currentRoot}
          onNodeClick={handleNodeClick}
          onUpdateParent={handleUpdateParent}
        />
      </main>

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onUpdate={handleParentUpdate}
        currentNode={selectedNode}
      />
    </div>
  );
}

export default App;
