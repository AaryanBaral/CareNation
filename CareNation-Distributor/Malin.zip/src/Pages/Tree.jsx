import React, { useEffect, useRef, useState } from 'react';
import TreeNode from './TreeNode.jsx';

const Tree = ({ rootNode, onNodeClick, onUpdateParent }) => {
  // Helper function to get up to 3 levels of the tree
  const getLevels = (node, maxLevels = 3) => {
    const levels = [];
    
    const buildLevel = (nodes, currentLevel) => {
      if (currentLevel >= maxLevels || !nodes || nodes.length === 0) {
        return;
      }
      
      levels[currentLevel] = nodes;
      
      const nextLevelNodes = [];
      nodes.forEach(node => {
        if (node.children && node.children.length > 0) {
          nextLevelNodes.push(...node.children);
        }
      });
      
      if (nextLevelNodes.length > 0) {
        buildLevel(nextLevelNodes, currentLevel + 1);
      }
    };
    
    buildLevel([node], 0);
    return levels;
  };

  const levels = getLevels(rootNode);
  const treeRef = useRef(null);
  const [connections, setConnections] = useState([]);

  // Calculate connector lines
  useEffect(() => {
    if (!treeRef.current) return;

    const calculateConnections = () => {
      const newConnections = [];
      const treeRect = treeRef.current.getBoundingClientRect();
      
      levels.forEach((level, levelIndex) => {
        if (levelIndex >= levels.length - 1) return; // Skip last level (no children)
        
        level.forEach((parentNode) => {
          if (!parentNode.children || parentNode.children.length === 0) return;
          
          const parentElement = treeRef.current.querySelector(`[data-node-id="${parentNode.id}"]`);
          if (!parentElement) return;
          
          const parentRect = parentElement.getBoundingClientRect();
          const parentCenterX = parentRect.left + parentRect.width / 2 - treeRect.left;
          const parentBottomY = parentRect.bottom - treeRect.top;
          
          const children = parentNode.children;
          const childElements = children.map(child => 
            treeRef.current.querySelector(`[data-node-id="${child.id}"]`)
          ).filter(Boolean);
          
          if (childElements.length === 0) return;
          
          const childPositions = childElements.map(childEl => {
            const childRect = childEl.getBoundingClientRect();
            return {
              centerX: childRect.left + childRect.width / 2 - treeRect.left,
              topY: childRect.top - treeRect.top
            };
          });
          
          // Calculate connector lines for T-shape
          if (childPositions.length === 1) {
            // Single child - straight line down
            newConnections.push({
              type: 'line',
              x1: parentCenterX,
              y1: parentBottomY,
              x2: childPositions[0].centerX,
              y2: childPositions[0].topY,
              key: `${parentNode.id}-${children[0].id}`
            });
          } else if (childPositions.length === 2) {
            // Two children - T-shape
            const leftChild = childPositions[0].centerX < childPositions[1].centerX ? childPositions[0] : childPositions[1];
            const rightChild = childPositions[0].centerX < childPositions[1].centerX ? childPositions[1] : childPositions[0];
            
            const verticalDropHeight = 30;
            const horizontalY = parentBottomY + verticalDropHeight;
            
            // Vertical line down from parent
            newConnections.push({
              type: 'line',
              x1: parentCenterX,
              y1: parentBottomY,
              x2: parentCenterX,
              y2: horizontalY,
              key: `${parentNode.id}-vertical`
            });
            
            // Horizontal line between children
            newConnections.push({
              type: 'line',
              x1: leftChild.centerX,
              y1: horizontalY,
              x2: rightChild.centerX,
              y2: horizontalY,
              key: `${parentNode.id}-horizontal`
            });
            
            // Vertical lines down to each child
            newConnections.push({
              type: 'line',
              x1: leftChild.centerX,
              y1: horizontalY,
              x2: leftChild.centerX,
              y2: leftChild.topY,
              key: `${parentNode.id}-left-child`
            });
            
            newConnections.push({
              type: 'line',
              x1: rightChild.centerX,
              y1: horizontalY,
              x2: rightChild.centerX,
              y2: rightChild.topY,
              key: `${parentNode.id}-right-child`
            });
          }
        });
      });
      
      setConnections(newConnections);
    };

    // Calculate on mount and when window resizes
    const timeoutId = setTimeout(calculateConnections, 100);
    const handleResize = () => {
      setTimeout(calculateConnections, 100);
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('resize', handleResize);
    };
  }, [levels, rootNode]);

  return (
    <div className="tree" ref={treeRef}>
      {/* SVG overlay for connector lines */}
      {connections.length > 0 && (
        <svg 
          className="tree-connections" 
          style={{
            width: '100%',
            height: '100%',
            position: 'absolute',
            top: 0,
            left: 0,
            pointerEvents: 'none',
            zIndex: 1
          }}
        >
          {connections.map((connection, index) => (
            <line
              key={connection.key}
              x1={connection.x1}
              y1={connection.y1}
              x2={connection.x2}
              y2={connection.y2}
              stroke="#222"
              strokeWidth="2"
              className="connector-line"
              style={{
                animationDelay: `${index * 0.1}s`
              }}
            />
          ))}
        </svg>
      )}
      
      {levels.map((level, levelIndex) => (
        <div key={levelIndex} className="tree-level">
          {level.map((node, nodeIndex) => (
            <TreeNode
              key={node.id}
              node={node}
              isRoot={levelIndex === 0 && nodeIndex === 0}
              onNodeClick={onNodeClick}
              onUpdateParent={onUpdateParent}
            />
          ))}
        </div>
      ))}
    </div>
  );
};

export default Tree;